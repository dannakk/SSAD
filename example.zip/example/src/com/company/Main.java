package com.company;
import java.util.Scanner; //importing scanner

public class Main {


    public static void main(String[] args) {
        Scanner myScanner = new Scanner(System.in);  //creating a Scanner
        System.out.println("Enter your string");
        String userName = myScanner.nextLine();  // Reading the input
        String input = userName.toLowerCase();

        StringBuilder sb=new StringBuilder(input);
        sb.reverse();
        String reversedString=sb.toString();
        //System.out.println(reversedString);

        final String alphabet = "abcdefghijklmnopqrstuvwxyz";
        for(int i=0; i < reversedString.length(); i++){
            System.out.print(alphabet.indexOf(reversedString.charAt(i))+1+" ");
        }    }

}
